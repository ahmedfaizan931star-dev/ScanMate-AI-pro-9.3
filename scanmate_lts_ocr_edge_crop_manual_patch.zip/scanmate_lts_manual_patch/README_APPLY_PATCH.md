# ScanMate AI Pro LTS Manual Patch Pack

This ZIP does **not** update GitHub. It is a local/manual patch pack for your existing repository.

## What it changes

1. Adds `OcrPostProcessor.kt`
   - Conservative OCR cleanup.
   - Fixes domain spacing such as `itseries. com.pk` -> `itseries.com.pk`.
   - Fixes email spacing such as `info @ itseries . com . pk` -> `[info@itseries.com.pk](mailto:info@itseries.com.pk)`.
   - Adds a small built-in dictionary for common document/book words.
   - Uses edit-distance carefully and avoids risky global character replacements.

2. Adds `OcrCustomDictionaryStore.kt`
   - Local-only custom dictionary helper.
   - Uses SharedPreferences, no account/cloud/backend.
   - Add/remove/list/clear custom words.

3. Patches `OcrHelper.kt`
   - Routes OCR cleanup through `OcrPostProcessor.normalize(...)`.
   - This keeps the existing OCR/export pipeline intact.

4. Patches `ImageProcessor.kt`
   - Safer auto document bounds detection.
   - Rejects weak detections, tiny crops, extreme aspect ratios, and suspicious edge-touching crops.
   - Uses outward padding to avoid cutting page content.

5. Patches `PageEditorScreen.kt`
   - Larger crop/corner dialogs.
   - More visible drag handles.
   - Fit page and reset actions.
   - Invalid-corner feedback and safer apply state.

## How to apply

Copy `apply_scanmate_lts_patch.py` into the root folder of your project, where `settings.gradle.kts` exists.

Then run:

```bash
python apply_scanmate_lts_patch.py
```

Then verify:

```bash
./gradlew clean assembleDebug
./gradlew testDebugUnitTest
./gradlew lintDebug
```

If release signing is configured:

```bash
./gradlew assembleRelease
./gradlew bundleRelease
```

## Important

The script creates `.bak` backups beside each edited file.
If anything does not build, restore the `.bak` files and send me the exact Gradle error.
