
package com.synthbyte.scanmate.util

import android.graphics.*
import androidx.camera.core.ImageProxy
import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Very lightweight document edge detector that searches for the largest bright rectangle‑like
 * region in a down‑sampled grayscale image.  It is **not** as robust as an OpenCV contour
 * detector but is good enough for typical overhead‑shot documents without adding native deps.
 *
 * 1. Down‑samples the Y‑plane to 320×240 resolution.
 * 2. Thresholds pixels above the local mean to a binary mask.
 * 3. Uses row / column projections to find the tight bounding box of the biggest white blob.
 * 4. Returns its four corner coordinates normalised to [0‥1] so the caller can map them onto
 *    any preview size easily.
 */
object EdgeAnalyzer {

    fun ImageProxy.toGrayscaleBitmap(): Bitmap {
        val yPlane = planes[0]
        val w = width
        val h = height
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val buffer = yPlane.buffer
        buffer.rewind()
        val rowStride = yPlane.rowStride
        val pixels = IntArray(w * h)
        var oy = 0
        val row = ByteArray(rowStride)
        for (y in 0 until h) {
            buffer.get(row, 0, rowStride)
            for (x in 0 until w) {
                val luma = row[x].toInt() and 0xFF
                val c = Color.rgb(luma, luma, luma)
                pixels[oy + x] = c
            }
            oy += w
        }
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    data class Result(val corners: List<Offset>, val confidence: Float)

    fun detect(image: ImageProxy): Result? {
        return try {
            val bmp = image.toGrayscaleBitmap()
            // Downscale for speed
            val scaled = Bitmap.createScaledBitmap(bmp, 320, 240, true)
            val w = scaled.width
            val h = scaled.height
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)

            // Compute global mean luminance
            var sum = 0
            for (v in pixels) sum += Color.red(v)
            val mean = sum / pixels.size

            // Threshold mask
            val mask = BooleanArray(pixels.size)
            for (i in pixels.indices) {
                mask[i] = Color.red(pixels[i]) > mean
            }

            // Row & column projections
            val rowSum = IntArray(h)
            val colSum = IntArray(w)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    if (mask[y * w + x]) {
                        rowSum[y]++
                        colSum[x]++
                    }
                }
            }

            // Find contiguous intervals with most bright pixels
            fun findBounds(sumArray: IntArray): Pair<Int, Int>? {
                val threshold = sumArray.maxOrNull()?.times(0.35)?.toInt() ?: return null
                var start = -1
                var bestStart = 0
                var bestEnd = 0
                var bestLen = 0
                for (i in sumArray.indices) {
                    if (sumArray[i] > threshold) {
                        if (start == -1) start = i
                    } else if (start != -1) {
                        val len = i - start
                        if (len > bestLen) {
                            bestLen = len
                            bestStart = start
                            bestEnd = i - 1
                        }
                        start = -1
                    }
                }
                if (bestLen == 0 && start != -1) {
                    bestStart = start
                    bestEnd = sumArray.size - 1
                }
                if (bestEnd > bestStart) return bestStart to bestEnd
                return null
            }

            val vert = findBounds(rowSum) ?: return null
            val horiz = findBounds(colSum) ?: return null

            val left = horiz.first.toFloat() / w
            val right = horiz.second.toFloat() / w
            val top = vert.first.toFloat() / h
            val bottom = vert.second.toFloat() / h

            val area = (right - left) * (bottom - top)
            val confidence = area

            val corners = listOf(
                Offset(left, top),
                Offset(right, top),
                Offset(right, bottom),
                Offset(left, bottom)
            )
            Result(corners, confidence)
        } catch (ex: Exception) {
            null
        }
    }
}
