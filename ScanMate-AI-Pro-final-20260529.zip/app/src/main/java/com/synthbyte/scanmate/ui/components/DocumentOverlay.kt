
package com.synthbyte.scanmate.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.StrokeWidth
import androidx.compose.ui.unit.dp

/**
 * Draws an animated green quadrilateral given document corner offsets that are *already*
 * expressed in the parent's coordinate space (0‥width, 0‥height).
 */
@Composable
fun DocumentOverlay(corners: List<Offset>?) {
    if (corners == null || corners.size != 4) return
    // Animate each corner for a smoother feel when the detector jitters
    val tl by animateOffsetAsState(corners[0], label = "tl", spring(stiffness = Spring.StiffnessMediumLow))
    val tr by animateOffsetAsState(corners[1], label = "tr", spring(stiffness = Spring.StiffnessMediumLow))
    val br by animateOffsetAsState(corners[2], label = "br", spring(stiffness = Spring.StiffnessMediumLow))
    val bl by animateOffsetAsState(corners[3], label = "bl", spring(stiffness = Spring.StiffnessMediumLow))

    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val path = Path().apply {
                moveTo(tl.x, tl.y)
                lineTo(tr.x, tr.y)
                lineTo(br.x, br.y)
                lineTo(bl.x, bl.y)
                close()
            }
            drawPath(
                path = path,
                color = Color(0xFF00E676),
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}
