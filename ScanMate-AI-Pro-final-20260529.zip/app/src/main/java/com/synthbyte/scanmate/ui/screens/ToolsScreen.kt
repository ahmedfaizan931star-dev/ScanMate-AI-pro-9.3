package com.synthbyte.scanmate.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

private enum class ToolTone { PRIMARY, ACCENT, DANGER, NEUTRAL }

private data class ToolDestination(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tone: ToolTone,
    val onClick: () -> Unit
)

@Composable
fun ToolsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToPdfTools: () -> Unit,
    onNavigateToQr: () -> Unit,
    onNavigateToQrScanner: () -> Unit,
    onNavigateToTranslate: () -> Unit,
    onNavigateToAi: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToZip: () -> Unit,
    onNavigateToFiles: () -> Unit
) {
    val tools = listOf(
        ToolDestination("PDF Tools", "Combine, export, split and share", Icons.Default.PictureAsPdf, ToolTone.PRIMARY, onNavigateToPdfTools),
        ToolDestination("QR Generator", "Create custom QR codes", Icons.Default.QrCode2, ToolTone.ACCENT, onNavigateToQr),
        ToolDestination("QR Scanner", "Scan codes with camera", Icons.Default.CameraAlt, ToolTone.ACCENT, onNavigateToQrScanner),
        ToolDestination("OCR Translate", "Extract and translate text", Icons.Default.Translate, ToolTone.PRIMARY, onNavigateToTranslate),
        ToolDestination("AI Workspace", "Summarize, ask, generate", Icons.Default.AutoAwesome, ToolTone.PRIMARY, onNavigateToAi),
        ToolDestination("Vault", "Lock sensitive documents", Icons.Default.Lock, ToolTone.DANGER, onNavigateToVault),
        ToolDestination("ZIP Export", "Bundle multiple files", Icons.Default.FolderZip, ToolTone.PRIMARY, onNavigateToZip),
        ToolDestination("File Manager", "Browse workspaces", Icons.Default.Folder, ToolTone.NEUTRAL, onNavigateToFiles)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Tools") },
                navigationIcon = { IconButton(onClick = onNavigateBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 156.dp),
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(bottom = 4.dp)) {
                    Text(
                        text = "ALL TOOLS",
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp,
                        letterSpacing = 0.14.em
                    )
                    Text("Everything you need", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("Work with scanned documents without login, cloud sync, or backend lock-in.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            }
            items(tools) { tool -> ToolCard(tool) }
        }
    }
}

@Composable
private fun colorsForTone(tone: ToolTone): Pair<Color, Color> = when (tone) {
    ToolTone.PRIMARY -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
    ToolTone.ACCENT -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.secondary
    ToolTone.DANGER -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.error
    ToolTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
private fun ToolCard(tool: ToolDestination) {
    val (iconContainer, iconTint) = colorsForTone(tool.tone)
    Card(
        onClick = tool.onClick,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier.size(38.dp).background(iconContainer, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(tool.icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(21.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(tool.title, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                Text(tool.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            }
        }
    }
}
