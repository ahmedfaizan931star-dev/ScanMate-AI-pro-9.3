package com.synthbyte.scanmate.ui.screens

import androidx.compose.runtime.mutableIntStateOf
import com.synthbyte.scanmate.util.EdgeAnalyzer
import com.synthbyte.scanmate.ui.components.DocumentOverlay
import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.material3.AssistChipDefaults
import android.os.Handler
import android.os.Looper

import androidx.camera.core.ImageProxy

import androidx.camera.core.ImageAnalysis

import android.Manifest
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.synthbyte.scanmate.data.SettingsRepository
import com.synthbyte.scanmate.utils.FileUtils
import com.synthbyte.scanmate.ui.viewmodels.rememberCameraViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import androidx.compose.foundation.clickable
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ListItem
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlipCameraAndroid

private 
enum class ScanQuality(val label: String, val jpegQuality: Int, val captureMode: Int) {
    STANDARD("Standard", 84, ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY),
    HIGH("High", 94, ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY),
    MAX("Max", 100, ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
}


private enum class ScanAspect(val label: String, val cameraValue: Int) {
    RATIO_4_3("4:3", AspectRatio.RATIO_4_3),
    RATIO_16_9("16:9", AspectRatio.RATIO_16_9)
}

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(onNavigateBack: () -> Unit, onScanFinished: (Long) -> Unit) {


// ---------- Auto edge detection & ImageAnalysis ----------
var autoDetectEnabled by remember { mutableStateOf(true) }
var stableFrameCount by remember { mutableIntStateOf(0) }
var detectedCorners by remember { mutableStateOf<List<Offset>?>(null) }

val edgeAnalyzer = remember {
    ImageAnalysis.Builder()
        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        .build().also { useCase ->
            useCase.setAnalyzer(Dispatchers.Default.asExecutor()) { image: ImageProxy ->
                try {
                    val result = EdgeAnalyzer.detect(image)
                    if (result != null) {
                        detectedCorners = result.corners
                        if (result.confidence > 0.85f) {
                            stableFrameCount++
                            if (stableFrameCount >= 12 && autoDetectEnabled) {
                                // Trigger capture on main thread
                                Handler(Looper.getMainLooper()).post {
                                    takePicture()
                                }
                                stableFrameCount = 0
                            }
                        } else stableFrameCount = 0
                    } else {
                        detectedCorners = null
                        stableFrameCount = 0
                    }
                } finally {
                    image.close()
                }
            }
        }
}
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)

    if (!cameraPermissionState.status.isGranted) {
        CameraPermissionState(onNavigateBack = onNavigateBack) {
            cameraPermissionState.launchPermissionRequest()
        }
        return
    }

    val context = LocalContext.current
    val viewModel = rememberCameraViewModel()
    val settingsRepository = remember { SettingsRepository(context) }
    val defaultWorkspace by settingsRepository.defaultWorkspaceFlow.collectAsState(initial = "Inbox")
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val capturedImages = remember { mutableStateListOf<File>() }

// Helper function to trigger a photo capture and store the temp file
private fun takePicture() {
    if (isSaving || isFinishing) return
    val capture = imageCapture ?: return
    val photoFile = File.createTempFile("scanmate_", ".jpg", context.cacheDir)
    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
    isSaving = true
    capture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                capturedImages.add(photoFile)
                isSaving = false
                Toast.makeText(context, "Captured", Toast.LENGTH_SHORT).show()
            }

            override fun onError(exception: ImageCaptureException) {
                isSaving = false
                Toast.makeText(context, "Capture failed: ${'$'}{exception.message}", Toast.LENGTH_SHORT).show()
            }
        }
    )
}
    val coroutineScope = rememberCoroutineScope()

    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(ScanQuality.HIGH) }
    var aspect by remember { mutableStateOf(ScanAspect.RATIO_4_3) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var torchEnabled by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var isFinishing by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            runCatching { ProcessCameraProvider.getInstance(context).get().unbindAll() }
        }
    }

    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 30)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                isSaving = true
                val imported = viewModel.importUris(uris)
                capturedImages.addAll(imported)
                isSaving = false
                Toast.makeText(
                    context,
                    if (imported.isNotEmpty()) "Imported ${imported.size} image(s)" else "No images could be imported",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    LaunchedEffect(lensFacing, quality, aspect) {
        cameraError = null
        runCatching {
            val cameraProvider = awaitCameraProvider(context)
            val requestedSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            val selector = if (cameraProvider.hasCamera(requestedSelector)) {
                requestedSelector
            } else {
                val fallbackSelector = CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK).build()
                if (cameraProvider.hasCamera(fallbackSelector)) {
                    lensFacing = CameraSelector.LENS_FACING_BACK
                    cameraError = "Selected camera is not available. Using rear camera instead."
                    fallbackSelector
                } else {
                    cameraError = "No compatible camera was found on this device."
                    null
                }
            }
            if (selector != null) {
                val preview = Preview.Builder()
                    .setTargetAspectRatio(aspect.cameraValue)
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setTargetAspectRatio(aspect.cameraValue)
                    .setCaptureMode(quality.captureMode)
                    .setJpegQuality(quality.jpegQuality)
                    .build()

                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                imageCapture = capture
                torchEnabled = false
            }
        }.onFailure { throwable ->
            Log.e("CameraScreen", "Camera bind failed", throwable)
            cameraError = throwable.localizedMessage ?: "Camera failed to start."
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())


// Document edge overlay
val overlayCorners = detectedCorners?.map { src ->
    Offset(src.x * previewView.width, src.y * previewView.height)
}
DocumentOverlay(corners = overlayCorners)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
                AssistChip(
                    onClick = {},
                    label = { Text("${capturedImages.size} page${if (capturedImages.size == 1) "" else "s"}") }
                )
            }

            cameraError?.let { error ->
                Text(
                    text = error,
                    color = Color.White,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.67f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                )
            }
        }


// ---------- Camera Controls (2‑row compressed) ----------

if (showSettingsSheet) {
    ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
        Column(Modifier.padding(24.dp)) {
            Text("Aspect ratio", style = MaterialTheme.typography.titleMedium)
            ScanAspect.entries.forEach { option ->
                ListItem(
                    headlineText = { Text(option.label) },
                    modifier = Modifier.clickable {
                        aspect = option
                        showSettingsSheet = false
                    },
                    trailingContent = {
                        if (aspect == option) Icon(Icons.Default.Check, contentDescription = null)
                    }
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("Current quality: ${quality.label}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
Column(
    modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .background(Color.Black.copy(alpha = 0.88f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
        .padding(horizontal = 16.dp, vertical = 12.dp)
) {
    // ROW 1
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            }) {
                Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Flip", tint = Color.White)
            }
            IconButton(
                onClick = {
                    torchEnabled = !torchEnabled
                    camera?.cameraControl?.enableTorch(torchEnabled)
                }
            ) {
                Icon(
                    if (torchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    contentDescription = "Torch",
                    tint = Color.White
                )
            }
            IconButton(onClick = {
                galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery", tint = Color.White)
            }

            // Auto‑detect toggle chip
            AssistChip(
                onClick = { autoDetectEnabled = !autoDetectEnabled },
                label = { Text(if (autoDetectEnabled) "Auto ✓" else "Auto ✗") },
                shape = RoundedCornerShape(50),
                colors = AssistChipDefaults.assistChipColors(
                    labelColor = Color.White,
                    containerColor = if (autoDetectEnabled) MaterialTheme.colorScheme.primary else Color.DarkGray
                )
            )
        }

        // Quality pills
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ScanQuality.entries.forEach { option ->
                FilterChip(
                    selected = quality == option,
                    onClick = { quality = option },
                    label = { Text(option.label.first().toString()) },
                    shape = RoundedCornerShape(50)
                )
            }
        }

        // Settings button for aspect & quality info
        IconButton(onClick = { showSettingsSheet = true }) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
        }
    }

    Spacer(Modifier.height(12.dp))

    // ROW 2
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(modifier = Modifier.width(1.dp)) // placeholder for left empty space
        // Shutter
        FloatingActionButton(
            onClick = {
                if (isSaving || isFinishing) return@FloatingActionButton
                takePicture()
            },
            shape = CircleShape,
            containerColor = Color.White,
            modifier = Modifier.size(68.dp),
            elevation = FloatingActionButtonDefaults.elevation(0.dp)
        ) {}
        // Done button
        FloatingActionButton(
            onClick = {
                if (capturedImages.isEmpty()) {
                    Toast.makeText(context, "No pages captured", Toast.LENGTH_SHORT).show()
                    return@FloatingActionButton
                }
                isFinishing = true
                coroutineScope.launch { saveCapturedImagesAndFinish() }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(52.dp),
            elevation = FloatingActionButtonDefaults.elevation(8.dp)
        ) {
            if (isFinishing) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
            } else {
                Icon(Icons.Default.Done, contentDescription = "Done", tint = Color.White)
            }
        }
    }
}
    }
}

@Composable
private fun CameraPermissionState(onNavigateBack: () -> Unit, onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Camera permission is required to scan documents.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("ScanMate keeps scanning offline and only uses the camera after you grant permission.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(18.dp))
        Button(onClick = onRequestPermission) { Text("Grant Permission") }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(onClick = onNavigateBack) { Text("Back") }
    }
}

private suspend fun awaitCameraProvider(context: Context): ProcessCameraProvider = suspendCancellableCoroutine { continuation ->
    val future = ProcessCameraProvider.getInstance(context)
    future.addListener(
        {
            try {
                if (continuation.isActive) continuation.resume(future.get())
            } catch (e: Exception) {
                if (continuation.isActive) continuation.resumeWithException(e)
            }
        },
        ContextCompat.getMainExecutor(context)
    )
}