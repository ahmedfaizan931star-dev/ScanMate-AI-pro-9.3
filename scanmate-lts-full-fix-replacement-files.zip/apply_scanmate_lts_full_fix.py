#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path.cwd()
PACK = Path(__file__).resolve().parent
FILES = [
    'app/src/main/java/com/synthbyte/scanmate/util/EdgeAnalyzer.kt',
    'app/src/main/java/com/synthbyte/scanmate/utils/FileCore.kt',
    'app/src/main/java/com/synthbyte/scanmate/utils/FileUtils.kt',
    'app/src/main/java/com/synthbyte/scanmate/utils/EncryptedVaultUtils.kt',
    'app/src/main/java/com/synthbyte/scanmate/utils/OcrPostProcessor.kt',
    'app/src/main/java/com/synthbyte/scanmate/utils/OcrHelper.kt',
    'app/src/main/java/com/synthbyte/scanmate/ui/screens/CameraScreen.kt',
    'app/src/main/java/com/synthbyte/scanmate/ui/screens/QrScannerScreen.kt',
    'app/src/main/java/com/synthbyte/scanmate/ui/screens/VaultScreen.kt',
    'app/src/main/java/com/synthbyte/scanmate/ui/screens/DocumentDetailScreen.kt',
    'app/src/main/java/com/synthbyte/scanmate/ui/viewmodels/DocumentDetailViewModel.kt',
]

if not (ROOT / 'settings.gradle.kts').exists() and not (ROOT / 'settings.gradle').exists():
    raise SystemExit('Run this from the repo root where settings.gradle(.kts) exists.')

for rel in FILES:
    src = PACK / rel
    dst = ROOT / rel
    if not src.exists():
        raise SystemExit(f'Missing pack file: {rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f'updated {rel}')

readme = PACK / 'SCANMATE_LTS_FULL_FIX_README.md'
if readme.exists():
    shutil.copy2(readme, ROOT / 'SCANMATE_LTS_FULL_FIX_README.md')
    print('added SCANMATE_LTS_FULL_FIX_README.md')

print('\nDone. Now run: ./gradlew :app:assembleDebug --stacktrace')
