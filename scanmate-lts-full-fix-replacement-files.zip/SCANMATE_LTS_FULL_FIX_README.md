# ScanMate AI Pro — LTS Full Fix Pack

This ZIP contains full replacement files, not snippets.

## Replace/update locations

Copy or unzip from repo root. These files are included:

- `app/src/main/java/com/synthbyte/scanmate/util/EdgeAnalyzer.kt`
- `app/src/main/java/com/synthbyte/scanmate/utils/FileCore.kt`
- `app/src/main/java/com/synthbyte/scanmate/utils/FileUtils.kt`
- `app/src/main/java/com/synthbyte/scanmate/utils/EncryptedVaultUtils.kt`
- `app/src/main/java/com/synthbyte/scanmate/utils/OcrPostProcessor.kt`
- `app/src/main/java/com/synthbyte/scanmate/utils/OcrHelper.kt`
- `app/src/main/java/com/synthbyte/scanmate/ui/screens/CameraScreen.kt`
- `app/src/main/java/com/synthbyte/scanmate/ui/screens/QrScannerScreen.kt`
- `app/src/main/java/com/synthbyte/scanmate/ui/screens/VaultScreen.kt`
- `app/src/main/java/com/synthbyte/scanmate/ui/screens/DocumentDetailScreen.kt`
- `app/src/main/java/com/synthbyte/scanmate/ui/viewmodels/DocumentDetailViewModel.kt`

## Main fixes

- Manual scan mode is now default. Auto edges can be enabled from the camera chip.
- Captured/imported/generated outputs go under app-managed `ScanMate AI` root folder.
- QR scanner result actions are horizontally scrollable so `Scan again` does not collapse vertically.
- Vault now supports encrypted files/images/documents, not only OCR text.
- Moving a document to Vault encrypts first, then deletes original page files and document record only after successful vault save.
- Vault screen requires biometric/device credential instead of opening automatically when auth is unavailable.
- OCR post-processing has stronger English textbook cleanup and better candidate scoring.
- Edge analyzer v2 is included as original safe code with no copied GitHub scanner implementation.

## Apply

```bash
cd /workspaces/ScanMate-AI-pro-9.3
unzip -o scanmate-lts-full-fix-replacement-files.zip
./gradlew :app:assembleDebug --stacktrace
```

If build succeeds:

```bash
git status
git add app/src/main/java/com/synthbyte/scanmate SCANMATE_LTS_FULL_FIX_README.md
git commit -m "Apply LTS full fixes for OCR vault storage and scanner UX"
git push origin main
```

## Honest OCR note

This improves OCR preprocessing/post-processing and English cleanup. No offline ML Kit OCR app can honestly guarantee 95% accuracy for every photo because accuracy depends on focus, lighting, crop, angle, page curvature and camera quality.
